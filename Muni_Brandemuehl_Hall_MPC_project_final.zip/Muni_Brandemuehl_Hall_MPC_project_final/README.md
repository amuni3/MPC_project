# MPC_project
Temperature control using MPC (ETH MPC course project)
